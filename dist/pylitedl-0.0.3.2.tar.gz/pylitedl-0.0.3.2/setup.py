from setuptools import setup

setup(
    name='PyLitedl',
    version='0.0.3.2',
    install_requires=['numpy', 'scipy'],
    packages=['lite'],
    url='',
    license='',
    author='macbook',
    author_email='buildaiorg@gmail.com',
    description='a mini deep learning framework',
    author_description="this uses scipy and cv2 and it is a good deep "

)
